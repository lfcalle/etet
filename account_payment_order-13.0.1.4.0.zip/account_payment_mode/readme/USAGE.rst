This module doesn't add any feature, but it is used by several other modules.
